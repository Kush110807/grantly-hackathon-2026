# Commands and environment

Repository: /workspace/grantly-hackathon-2026

Application cwd for every npm/application command: /workspace/grantly-hackathon-2026/GRANTLY_GITHUB_SOURCE_ONLY

QA root: /workspace/grantly-qa (outside the checkout). Evidence root: /workspace/grantly-qa/evidence.

Environment: Debian GNU/Linux 13 userland, Linux 6.18.57 x86_64; Node 24.22.1; npm 11.9.0; Chromium 156.0.8078.79; Playwright 1.57.0 supplied by the environment at /opt/codex/cua_node/lib/node_modules/playwright; axe-core 4.14.0 installed only in the external harness. UTC logs correspond to IST = UTC+05:30.

## Baseline and checks

```bash
git -C /workspace/grantly-hackathon-2026 rev-parse HEAD
git -C /workspace/grantly-hackathon-2026 status --short
cd /workspace/grantly-hackathon-2026/GRANTLY_GITHUB_SOURCE_ONLY
npm run verify:integrated
npm run test:plan
node scripts/release-check.mjs
npm run build
```

All four check commands exit 0. Full stdout/stderr is under logs/. The build invokes npm run typecheck before vite build. Node package installation had already passed during the immediately preceding onboarding via `npm ci --cache /workspace/.npm-cache --no-audit --no-fund`; no application dependencies were changed during this QA. g1:verify was intentionally not run: README explicitly excludes that foundation-only gate for an integrated candidate.

## Audits (non-zero statuses preserved)

```bash
npm audit --json > /workspace/grantly-qa/evidence/audits/npm-audit.json 2> /workspace/grantly-qa/evidence/audits/npm-audit.stderr
audit_status=$? # 1
npm audit --omit=dev --json > /workspace/grantly-qa/evidence/audits/npm-audit-production.json 2> /workspace/grantly-qa/evidence/audits/npm-audit-production.stderr
production_audit_status=$? # 0
npm ls --all --json > /workspace/grantly-qa/evidence/audits/dependency-tree.json 2> /workspace/grantly-qa/evidence/audits/dependency-tree.stderr
# exit 0
```

Each command was executed without `set -e`, so a non-zero audit did not prevent the production audit. Audit exit codes are separate files, not inferred from the JSON or a shell pipeline. No audit fix or upgrades ran. Advisory pages were fetched via `curl -fsSL --max-time 25 https://github.com/advisories/<GHSA>`; harness/advisories.py records URL, fetch exit code and extracted description. All 26 fetches succeeded. These are live advisory observations at test time, not a frozen historic database.

## Loopback serving and isolated browser harness

The earlier onboarding's development and preview processes (PIDs 935 and 1125) were stopped with `kill -TERM 935 1125`. They were created in the same session. No development server was started for release QA.

```bash
npm run preview -- --host 127.0.0.1 --port 4173 --strictPort
ss -ltnp # confirmed 127.0.0.1:4173; no 5173 listener
npm install --prefix /workspace/grantly-qa/harness --cache /workspace/.npm-cache --no-audit --no-fund --save-exact axe-core
node /workspace/grantly-qa/harness/qa.mjs
# final primary runner exit 1: 20 pass; 1 desktop decorative-contrast flag
node /workspace/grantly-qa/harness/supplement.mjs
# exit 0: multiple-entry scenarios at all three widths; favicon diagnostic 404
node /workspace/grantly-qa/harness/native-zoom.mjs
# exit 1: unpacked extensions disabled by administrator; native zoom blocked
```

The package preview script contains an earlier --host 0.0.0.0 argument; the final explicit --host 127.0.0.1 overrides it. Socket inspection verified the effective bind. No preview URL was published. Browser contexts were fresh and isolated, with synthetic fictional demo data only. Storage failures were injected into Storage methods/window getter before navigation, solely in those browser contexts; neither production source nor browser data from a user profile was changed.

## Distribution inspection and preservation

```bash
# from application cwd
node /workspace/grantly-qa/harness/module-graph.mjs
# exit 0; inspection-only generateBundle observer, original config and cwd
python3 /workspace/grantly-qa/harness/inspect-artifact.py
# exit 0; all artifact hashes match original build; no scan hits
python3 /workspace/grantly-qa/harness/security-report.py
git -C /workspace/grantly-hackathon-2026 diff --exit-code
# exit 0
```

Tracked file hashes were recorded before and after all work, including src/**, manifest, lockfile, shared contracts and production configuration. All 55 tracked files are byte-identical. G2_INTEGRATION_MANIFEST.json lists 55 entries: 54 match; the .gitignore entry is missing in the original checkout. No replacement was created.

An initial module-graph command ran from /workspace and failed because the repository's Rollup input is the cwd-relative index.html. It transformed zero modules. Re-running from the documented application cwd succeeded; the observer rebuild reproduced all three original dist hashes exactly. Its initial error and successful retry logs are retained.

Primary browser initial runs had harness errors: a desktop inline-pane Back control is intentionally hidden; terms details stay open between selections; focus assertions raced the scheduled heading focus. The final harness handles these behaviors and waits for the scheduled focus. Initial and second logs are retained and superseded by browser-results.json. The supplementary script initially ended on a deliberate favicon document-navigation 404 before persisting results; it was corrected to inspect HTTP status with the request API and rerun fully. The correction changed only the external harness.

Packaging used Python zipfile with an explicit evidence directory, excluding node_modules, browser profiles and caches. A bundle SHA-256 and per-file evidence checksums accompany the final archive. No commits, pushes, deployments or submissions were made.
