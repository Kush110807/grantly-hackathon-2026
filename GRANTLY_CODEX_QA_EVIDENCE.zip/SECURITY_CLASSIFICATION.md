# Dependency security classification

Audit fetched 7 November 2026. Full unmodified JSON and stderr are in audits/. No audit fix or dependency change was performed.

`npm audit --json`: exit **1**, 18 affected package records: 10 high, 4 moderate, 4 low, 0 critical. These are package records including propagated findings, not 18 independent exploits.

`npm audit --omit=dev --json`: exit **0**, no reported production vulnerabilities. Browser runtime is React 19.2.4, react-dom 19.2.4 and transitive scheduler 0.27.0. The production module inventory confirms production React/scheduler plus application modules; Vite/PostCSS/Rollup/Babel are not browser runtime modules.

All affected package records below belong to development/build dependencies. A dev-only label does not protect a developer or CI host processing malicious input. No advisory exploit PoCs were run; classification uses dependency tree, configuration, compiled-module inventory and fetched GitHub advisory text.

## Affected packages

| Package | Installed version | Relationship | npm severity | Finding propagation |
| --- | --- | --- | --- | --- |
| @babel/core | 7.29.0 | Transitive dev/build | high | @babel/helper-compilation-targets, @babel/helper-module-transforms, GHSA-4x5r-pxfx-6jf8 |
| @babel/helper-compilation-targets | 7.28.6 | Transitive dev/build | high | browserslist |
| @babel/helper-module-transforms | 7.28.6 | Transitive dev/build | low | @babel/core |
| @babel/plugin-transform-react-jsx-self | 7.27.1 | Transitive dev/build | low | @babel/core |
| @babel/plugin-transform-react-jsx-source | 7.27.1 | Transitive dev/build | low | @babel/core |
| @vitejs/plugin-react | 5.1.3 | Direct devDependency | moderate | @babel/core, @babel/plugin-transform-react-jsx-self, @babel/plugin-transform-react-jsx-source, vite |
| baseline-browser-mapping | 2.9.19 | Transitive dev/build | moderate | GHSA-w5vr-8v7q-w6rv |
| browserslist | 4.28.1 | Transitive dev/build | high | GHSA-c83g-rgw3-j3cx, GHSA-73wf-gq98-2v4g, baseline-browser-mapping, update-browserslist-db |
| esbuild | 0.27.3 | Transitive dev/build | low | GHSA-g7r4-m6w7-qqqr |
| fdir | 6.5.0 | Transitive dev/build | moderate | picomatch |
| nanoid | 3.3.11 | Transitive dev/build | high | GHSA-28wg-ghj8-5hjv, GHSA-2v37-7h3g-55p8, GHSA-xwg4-73v4-xw9w |
| picomatch | 4.0.3 | Transitive dev/build | high | GHSA-3v7f-55p6-f55p, GHSA-c2c7-rcm5-vvqj |
| postcss | 8.5.6 | Transitive dev/build | high | GHSA-qx2v-qp2m-jg93, GHSA-6g55-p6wh-862q, GHSA-fxqj-rqcc-2cmp, GHSA-r28c-9q8g-f849, nanoid, source-map-js |
| rollup | 4.57.1 | Transitive dev/build | high | GHSA-mw96-cpmx-2vgc |
| source-map-js | 1.2.1 | Transitive dev/build | high | GHSA-68fv-2mgg-jv7q |
| tinyglobby | 0.2.15 | Transitive dev/build | moderate | fdir, picomatch |
| update-browserslist-db | 1.2.3 | Transitive dev/build | high | browserslist |
| vite | 7.3.1 | Direct devDependency | high | GHSA-4w7w-66w2-5vf9, GHSA-v2wj-q39q-566r, GHSA-p9ff-h696-f583, GHSA-v6wh-96g9-6wx3, GHSA-698v-4r3x-3vcv, GHSA-r825-w8mm-5pxw, GHSA-587h-7wmj-h5pm, GHSA-9jrq-w75r-8gcw, GHSA-rq7h-c2jc-7f22, GHSA-fx2h-pf6j-xcff, esbuild, fdir, picomatch, postcss, rollup, tinyglobby |

## Advisory conditions and observed scope

The severity below is each underlying advisory severity; parent package aggregate severity can differ. Complete fetched descriptions and reference links are preserved in audits/advisories/.

### @babel/core: GHSA-4x5r-pxfx-6jf8 (low)

@babel/core: Arbitrary File Read via sourceMappingURL Comment.

Affected range reported by audit: `<=7.29.0`. Attacker controls code compiled by Babel, knows source-map path and can read resulting output. Trusted-only compilation is not impacted according to advisory.

Source: https://github.com/advisories/GHSA-4x5r-pxfx-6jf8

### baseline-browser-mapping: GHSA-w5vr-8v7q-w6rv (moderate)

baseline-browser-mapping process termination on invalid input causes denial of service.

Affected range reported by audit: `>=2.0.0 <2.11.0`. Untrusted invalid/conflicting baseline-browser-mapping parameters can terminate calling process; build-tool input validation/availability risk.

Source: https://github.com/advisories/GHSA-w5vr-8v7q-w6rv

### browserslist: GHSA-c83g-rgw3-j3cx (high)

Browserslist: Unbounded memory growth (no cache eviction) via distinct query results, leading to eventual OOM.

Affected range reported by audit: `<=4.28.6`. Long-lived Browserslist caller accepts many distinct untrusted queries/context values; unbounded caches exhaust memory. Fixed trusted build queries here.

Source: https://github.com/advisories/GHSA-c83g-rgw3-j3cx

### browserslist: GHSA-73wf-gq98-2v4g (high)

Browserslist: Uncaught crash / prototype write via untrusted browserslist-stats.json custom stats (normalizeStats).

Affected range reported by audit: `<=4.28.6`. Untrusted browserslist-stats.json or programmatic stats can crash/prototype-write during normalization; prevent attacker-controlled build metadata.

Source: https://github.com/advisories/GHSA-73wf-gq98-2v4g

### esbuild: GHSA-g7r4-m6w7-qqqr (low)

esbuild allows arbitrary file read when running the development server on Windows.

Affected range reported by audit: `>=0.27.3 <0.28.1`. esbuild standalone serve on Windows with crafted backslash path traversals; no esbuild serve process used in this Linux static-preview QA.

Source: https://github.com/advisories/GHSA-g7r4-m6w7-qqqr

### nanoid: GHSA-28wg-ghj8-5hjv (high)

nanoid: non-secure generators can loop indefinitely with negative size.

Affected range reported by audit: `<3.3.16`. Attacker-controlled negative size passed to nanoid/non-secure generation can loop forever. No nanoid browser module bundled.

Source: https://github.com/advisories/GHSA-28wg-ghj8-5hjv

### nanoid: GHSA-2v37-7h3g-55p8 (high)

nanoid: custom generators can loop indefinitely when size is zero.

Affected range reported by audit: `<3.3.18`. Attacker-controlled zero size in customAlphabet/customRandom can loop forever. No nanoid browser module bundled.

Source: https://github.com/advisories/GHSA-2v37-7h3g-55p8

### nanoid: GHSA-xwg4-73v4-xw9w (high)

nanoid: Integer Overflow or Wraparound.

Affected range reported by audit: `<3.3.12`. Attacker-influenced huge nanoid size overflows signed integer, corrupting random pool and producing deterministic IDs. No nanoid browser module bundled.

Source: https://github.com/advisories/GHSA-xwg4-73v4-xw9w

### picomatch: GHSA-3v7f-55p6-f55p (moderate)

Picomatch: Method Injection in POSIX Character Classes causes incorrect Glob Matching.

Affected range reported by audit: `>=4.0.0 <4.0.4`. Untrusted POSIX bracket glob patterns can reference inherited object methods and alter matching; not remote code execution per advisory.

Source: https://github.com/advisories/GHSA-3v7f-55p6-f55p

### picomatch: GHSA-c2c7-rcm5-vvqj (high)

Picomatch has a ReDoS vulnerability via extglob quantifiers.

Affected range reported by audit: `>=4.0.0 <4.0.4`. Untrusted crafted extglob patterns plus nonmatching input cause catastrophic regex backtracking; developer-controlled glob patterns here.

Source: https://github.com/advisories/GHSA-c2c7-rcm5-vvqj

### postcss: GHSA-qx2v-qp2m-jg93 (moderate)

PostCSS has XSS via Unescaped </style> in its CSS Stringify Output.

Affected range reported by audit: `<8.5.10`. Attacker CSS is stringified and embedded unsafely in an HTML style element. GRANTLY ships trusted CSS as a separate linked .css asset; no user CSS pipeline found.

Source: https://github.com/advisories/GHSA-qx2v-qp2m-jg93

### postcss: GHSA-6g55-p6wh-862q (high)

PostCSS: Arbitrary file read and information disclosure via attacker-controlled sourceMappingURL in CSS comments.

Affected range reported by audit: `<=8.5.11`. Attacker controls CSS sourceMappingURL passed to PostCSS with previous-map loading; readable host paths and error/map output can expose files. Build-time input trust matters.

Source: https://github.com/advisories/GHSA-6g55-p6wh-862q

### postcss: GHSA-fxqj-rqcc-2cmp (moderate)

PostCSS: incomplete fix of GHSA-6g55-p6wh-862q — attacker-controlled sourceMappingURL reads arbitrary .map files when `from` is unset.

Affected range reported by audit: `<=8.5.22`. PostCSS incomplete source-map fix; attacker CSS sourceMappingURL, especially with from unset, reads arbitrary .map files. Trusted source build observed; no runtime CSS processing.

Source: https://github.com/advisories/GHSA-fxqj-rqcc-2cmp

### postcss: GHSA-r28c-9q8g-f849 (high)

PostCSS: Path Traversal in Previous Source Map Auto-Loading (sourceMappingURL) leads to Arbitrary .map File Disclosure.

Affected range reported by audit: `<=8.5.17`. PostCSS auto-loads previous .map from attacker-controlled CSS with traversal unless map loading disabled; generated maps can disclose sourcesContent. Trusted project CSS only observed.

Source: https://github.com/advisories/GHSA-r28c-9q8g-f849

### rollup: GHSA-mw96-cpmx-2vgc (high)

Rollup 4 has Arbitrary File Write via Path Traversal.

Affected range reported by audit: `>=4.0.0 <4.59.0`. Attacker controls Rollup named inputs, output aliases or plugin-generated filenames with traversal; build host arbitrary file write. Current trusted index.html input only.

Source: https://github.com/advisories/GHSA-mw96-cpmx-2vgc

### source-map-js: GHSA-68fv-2mgg-jv7q (high)

source-map-js allows event-loop denial of service through indexed source-map section offsets.

Affected range reported by audit: `>=1.0.0 <1.2.2`. Attacker supplies indexed source map with huge section offsets, blocking source-map-js event loop; build-tool availability risk, not bundled browser code.

Source: https://github.com/advisories/GHSA-68fv-2mgg-jv7q

### vite: GHSA-4w7w-66w2-5vf9 (moderate)

Vite Vulnerable to Path Traversal in Optimized Deps `.map` Handling.

Affected range reported by audit: `>=7.0.0 <=7.3.1`. Network-reachable Vite development server and predictable sensitive .map files; optimized-dependency map traversal. Not a static-dist endpoint.

Source: https://github.com/advisories/GHSA-4w7w-66w2-5vf9

### vite: GHSA-v2wj-q39q-566r (high)

Vite: `server.fs.deny` bypassed with queries.

Affected range reported by audit: `>=7.1.0 <=7.3.1`. Network-reachable development server; denied sensitive file exists within an allowed directory; query variants bypass fs.deny.

Source: https://github.com/advisories/GHSA-v2wj-q39q-566r

### vite: GHSA-p9ff-h696-f583 (high)

Vite Vulnerable to Arbitrary File Read via Vite Dev Server WebSocket.

Affected range reported by audit: `>=7.0.0 <=7.3.1`. Network-reachable development server with WebSocket enabled; attacker can connect without an Origin and invoke fetchModule. Arbitrary host file disclosure.

Source: https://github.com/advisories/GHSA-p9ff-h696-f583

### vite: GHSA-v6wh-96g9-6wx3 (moderate)

launch-editor: NTLMv2 hash disclosure via UNC path handling on Windows.

Affected range reported by audit: `>=7.0.0 <=7.3.4`. Windows with NTLM enabled, running launch-editor middleware, attacker website/request and known endpoint; UNC path can disclose NTLMv2 hash. Linux QA does not test Windows exploitability.

Source: https://github.com/advisories/GHSA-v6wh-96g9-6wx3

### vite: GHSA-698v-4r3x-3vcv (moderate)

launch-editor: escapeCmdArgs() omits % escaping on Windows.

Affected range reported by audit: `>=7.0.0 <=7.3.6`. Windows editor shell invocation with crafted filename plus malicious environment expansion or NTFS stream; percent escaping is incomplete. Later existence-check advisory weakens file-placement prerequisite.

Source: https://github.com/advisories/GHSA-698v-4r3x-3vcv

### vite: GHSA-r825-w8mm-5pxw (moderate)

launch-editor: Editor CLI flag misinterpretation causing arbitrary command execution for some editors.

Affected range reported by audit: `>=7.0.0 <=7.3.6`. Attacker-controlled + or - filesystem entry and susceptible editor; Vite-specific scenario requires WSL. Editor interprets filename as CLI commands/flags.

Source: https://github.com/advisories/GHSA-r825-w8mm-5pxw

### vite: GHSA-587h-7wmj-h5pm (high)

launch-editor: `fs.existsSync()` existence check can be bypassed on Windows.

Affected range reported by audit: `>=7.0.0 <=7.3.6`. Windows launch-editor path ending in backslash parent/line suffix bypasses existence check; combined with percent expansion issue can cause command injection.

Source: https://github.com/advisories/GHSA-587h-7wmj-h5pm

### vite: GHSA-9jrq-w75r-8gcw (low)

Vite: Cross origin script execution through Vite custom middleware.

Affected range reported by audit: `>=7.0.0 <=7.3.6`. Custom/middleware Vite app forwards unchanged request URL into transformIndexHtml, contains inline module, and exposes sensitive state/actions. Standard SPA internal call does not meet this condition; no custom middleware found here.

Source: https://github.com/advisories/GHSA-9jrq-w75r-8gcw

### vite: GHSA-rq7h-c2jc-7f22 (moderate)

Vite: Files outside `server.fs.allow` could be served when project paths match system paths on non-Windows machine.

Affected range reported by audit: `>=7.0.0 <=7.3.6`. Non-Windows network-exposed dev server; imported root-relative path also names a readable host absolute path, not denied by fs.deny. No matching project import observed.

Source: https://github.com/advisories/GHSA-rq7h-c2jc-7f22

### vite: GHSA-fx2h-pf6j-xcff (moderate)

vite: `server.fs.deny` bypass on Windows alternate paths.

Affected range reported by audit: `>=7.0.0 <=7.3.4`. Windows Vite development serving and alternate Windows path spellings bypass deny rules. Not Linux/static artifact.

Source: https://github.com/advisories/GHSA-fx2h-pf6j-xcff

## Vite and PostCSS release implications

Vite 7.3.1 is a direct devDependency. package.json dev and preview scripts explicitly bind 0.0.0.0; vite.config.ts also sets server.host to 0.0.0.0. The development server therefore meets the network-binding prerequisite of the three original Vite file-read advisories if reachable by an attacker. Actual external ingress was not probed. This QA stopped the earlier onboarding servers and only ran the production preview with the final explicit --host 127.0.0.1 override; ss confirmed 127.0.0.1:4173 and no 5173 listener. Preview/static hosting does not execute Vite development HMR/fetchModule handlers. Do not deploy npm run dev or npm run preview as production hosting.

PostCSS 8.5.6 is transitively installed through Vite. The XSS advisory requires unsafe embedding of attacker CSS into a style element; this artifact instead links a generated CSS asset. File-read advisories concern the Node build process ingesting attacker sourceMappingURL comments; they are not a browser endpoint in dist. Trusted source inputs were built here, but untrusted CSS/dependency contributions still require an isolated build host and patched tooling.

Recommended separate correction owned by Release Engineering/A: update the pinned Vite/plugin toolchain to compatible releases outside ALL reported advisory ranges; refresh affected transitives (PostCSS, Rollup, Babel, Browserslist/baseline mapping, source-map-js, nanoid, picomatch and esbuild) in a separate reviewed lockfile change. Vite 7.3.2 only addresses the original three advisories; later reported ranges extend through 7.3.6, so upgrading merely to 7.3.2 is insufficient. Some aggregate audit records report fixAvailable=false; resolve compatible versions explicitly rather than assuming audit fix works. Keep development/preview loopback-only by default in that separate change, then rerun audits, tests and browser QA against the NEW bytes.

Static artifact disposition: no known production dependency findings were reported by this audit, and affected development/build packages are absent from its JavaScript module inventory. No evidence here establishes that every vulnerability is absent or that build infrastructure is hardened. An unqualified clean-security release claim is FAIL until tooling findings are corrected or explicitly accepted with documented scope by the release authority.
