# GRANTLY G2-r3 — executable release QA evidence

**Disposition: HOLD for an unqualified release PASS.** The tested production artifact passes the functional browser scenarios and build checks. Remaining acceptance items are native 200% zoom, source-distribution manifest reconciliation, and disposition of development/build dependency vulnerabilities. No production-dependency vulnerabilities were reported by the executed audit. This report does not authorize deployment or submission.

Evidence completed on **7 November 2026, 3:38 PM IST**, before the stated 5:00 PM IST deadline. Machine-readable logs use UTC. Prepared by Codex acting as the requested release engineering/browser QA specialist; this is new executable evidence for Chat E's decision, not an inherited E certification.

## Exact candidate and preservation

- Repository root: `/workspace/grantly-hackathon-2026`.
- Application root: `/workspace/grantly-hackathon-2026/GRANTLY_GITHUB_SOURCE_ONLY`.
- Git commit: `157e0bb8b8eb6900cf2b652877139cbbba94bf3d`.
- Revision: `GRANTLY-A-G2-r3`, identified by `G2_INTEGRATION_MANIFEST.json`, `README_RELEASE_R3.md` and matching source hashes.
- Source preservation: **PASS**, all **55 tracked files** have identical before/after SHA-256 values. No source, tests, shared contracts, dependency manifests, lockfile or production configuration changed.
- Lockfile SHA-256: `f4f013b81d553aed34add2671efb29e78fc096a230274fb4a7f63929c5ff1102`.
- Manifest verification: **54 of 55 entries match**. The original checkout lacks `.gitignore`, which the G2-r3 manifest lists. There are no hash mismatches among existing manifest entries. See `manifest-verification.json`.
- Only the expected untracked `node_modules/` and generated `dist/` exist in the checkout. They were already present from onboarding; the build refreshed dist. No commits, pushes, deployments, submissions or dependency fixes occurred.

## Results and explicit status

| Check | Status | Executed evidence |
| --- | --- | --- |
| Integrated domain oracle | PASS | 236/236 assertions, `logs/integrated.log` |
| Integrated cross-lane/static checks | PASS | 35/35 assertions, same log |
| Plan model and storage tests | PASS | 13 tests; 0 fail, skip or cancel, `logs/plan.log` |
| r3 correction-presence assertions | PASS | 9/9, `logs/release-check.log` |
| TypeScript and production build | PASS | `npm run build`, exit 0; includes typecheck |
| Artifact inventory/hash isolation scan | PASS | 3 files; module graph excludes fixtures and preview entry; scan has no credential-pattern matches |
| Source-distribution manifest completeness | FAIL | Missing original `.gitignore`; 54 other entries match |
| Primary real-browser runner | 20 PASS / 1 FAIL | 21 completed cases; exit 1, `logs/browser-results.json` |
| Supplementary multi-entry browser scenarios | PASS | 1440px, 390px, 360px; exit 0, `logs/supplement-results.json` |
| Full dependency audit | FAIL | Exit 1; 18 affected package records: 10 high, 4 moderate, 4 low |
| Production dependency audit | PASS | Exit 0, 0 reported vulnerabilities |
| Native browser zoom at 200% | BLOCKED | Unpacked extension loading disabled by administrator; raw attempt logs included |
| 200% reflow-equivalent viewport | PASS | 720×450 CSS viewport; not misrepresented as native zoom |
| Screen reader / speech output | UNRUN | No assistive technology session executed |
| Firefox, WebKit, actual devices, Windows-specific exploits | UNRUN | Chromium/Linux automation only |
| Deployment, submission and hosted ingress/security configuration | UNRUN | Outside the authorized test scope |

The primary runner's one FAIL is an unsuppressed axe contrast finding on the desktop decorative “01/02” labels. These are aria-hidden ordinal decorations next to readable question text; manual classification is P3/decorative contrast exception candidate, requiring E's adjudication. It is not a functional test failure. Full axe JSON and incomplete checks are retained; no all-green accessibility claim is made.

## Functional browser coverage

The actual built artifact was served only at `127.0.0.1:4173`. Effective socket binding was checked; the development server was stopped. The QA preview was also stopped after testing, with no remaining 4173/5173 listeners. Playwright drove Chromium 156 using fresh synthetic contexts, not user browser data. The served index bytes match packaged dist/index.html.

The following ran at **1440×900, 390×844 and 360×844** in the primary harness (supplementary multi-entry cases used the same widths and 900px height):

1. Default open-only list shows five records; clearing the filter shows six, including closed Digital Access. Case-insensitive purpose search, no-match state, clearing filters and opportunity selection work. Mobile Back restores query and originating row focus. Desktop uses an inline reader; its Back is intentionally hidden. Plan-opened detail Back works at every width.
2. Meridian, Fieldwork and Bridge were each compared against Campus Tuition Waiver and Founders Tuition Award. Application permission is separately asserted from holding outcome. The observed matrix is below. Both-provider terms and Bridge's missing holding term were expanded and inspected.
3. Meridian year 3 is displayed as outside the listed year eligibility. The test did not rewrite eligibility rules. The domain oracle also executed its inclusive-date/missing-term/mandatory-row cases.
4. Bridge clarification can be saved, progress changed, refreshed and restored. Changing aid to FT raises review; acknowledging clears review without altering intention/progress. The original CW question survives aid change, acknowledgement and refresh exactly: “May I keep my Campus Tuition Waiver if I accept the Bridge Travel Bursary?”
5. Supplementary tests save Meridian as Alternative and Fieldwork as Pursue, persist two entries/progress through refresh, raise two independent reviews, acknowledge Fieldwork only, restore detail/Back focus, and remove Fieldwork.
6. Self-reported external submission shows an explicit “No submission was sent through GRANTLY” explanation. Reset cancel retains the plan; confirm clears only `grantly.v1`, leaving a synthetic unrelated origin key intact.

| Scholarship | Aid | Applying with aid | Holding both |
| --- | --- | --- | --- |
| Meridian | Campus Tuition Waiver | Permitted | Prohibited |
| Meridian | Founders Tuition Award | Permitted | Prohibited |
| Fieldwork | Campus Tuition Waiver | Permitted | Permitted |
| Fieldwork | Founders Tuition Award | Permitted | Prohibited |
| Bridge | Campus Tuition Waiver | Permitted | Unresolved — missing Bridge holding term |
| Bridge | Founders Tuition Award | Permitted | Prohibited — FT veto, missing Bridge term does not override it |

Storage browser fault injection separately exercised throwing setItem, silent no-op setItem, throwing getItem, throwing localStorage getter, malformed JSON, throwing removeItem and silent no-op removeItem. All seven cases passed their warning/reset expectations. Failed writes retain in-tab edits and show warnings; the neutral plan heading never claims device saving. Failed reads lock writes. Failed resets do not claim success or discard the in-memory plan; invalid data is removed only by successful confirmed reset. Native storage methods were overridden only inside isolated test contexts.

## Browser errors and accessibility

No application JavaScript pageerror was observed. One initial console error was a **404 for the absent favicon**, independently confirmed with an HTTP request. It is retained as a P3 polish issue, not hidden as “no console errors”. Supplementary runs observed no pageerrors or failed application responses.

Keyboard tests verified the skip link, Enter activation, heading/Back focus, stable aid-select focus and the actual polite live-region text separating application permitted from holding prohibited. A 35-step Tab trace is saved. Screenshots and DOM-based tests cannot prove spoken output; screen-reader acceptance is UNRUN.

There are **56 actual browser screenshots**, not static design specimens. Desktop, both mobile widths, aid scenarios, preservation/review, reset and injected storage faults are included. Selected desktop, 360px plan and reflow screenshots were visually inspected. No horizontal document overflow was detected in the checked layouts. See `ACCESSIBILITY_OBSERVATIONS.md` for raw axe interpretation, generic-div aria-label observations, native-zoom blocker and scope limits.

## Production distribution

The complete tested compiled artifact is included under `dist/`. No source maps or preview.html exist in dist. The production chunk's recorded module inventory contains real domain/discovery/plan/application code and production React/react-dom/scheduler modules, excluding fixture, preview-main, development React and Vite HMR modules. The real integration/live adapter is production wiring; it is not a development adapter and is tree-shaken into actual imports.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| assets/index-Bi9BC2CK.css | 40918 | afe7deb2c08ecc281a4befd34aa51b64ad759ff5376c4698e1e5049f3bbc8f95 |
| assets/index-CwYXjUCm.js | 238348 | 14bc63e776c0e58098039b0a4d434a0ed73f2b10131c37786556e6ed8d40849e |
| index.html | 428 | fa8d7ed79f9d9c1894b59efc7bfe1b82cb0bb4abf1f063e25288fcc6252006cf |

The machine-readable `dist-inventory.json` and `dist-SHA256SUMS.txt` are authoritative for byte counts and hashes. A generateBundle observer rebuild reproduced identical bytes. All compiled files were scanned for preview/development markers, private-key blocks, common service/cloud tokens, JWT-like strings and secret assignments; no matches were found. This is a bounded heuristic scan, not proof that every possible secret encoding is absent.

## Dependency security conclusion

Complete audit JSON, stderr and exact exit codes are included. `SECURITY_CLASSIFICATION.md` lists all affected direct/transitive packages, installed versions, advisory severity/conditions and 26 fetched GitHub advisory descriptions. No audit fix, upgrade or lockfile modification was performed.

Vite 7.3.1 and @vitejs/plugin-react are direct development dependencies; affected PostCSS, Rollup, Babel, Browserslist, esbuild and other packages are build/development transitives. They are not bundled as browser runtime packages. The network-binding prerequisite of the original Vite file-read advisories is present in the repository's default `--host 0.0.0.0` development script/config if attacker-reachable; this QA used no network-exposed development server. PostCSS findings involve attacker-controlled CSS/source maps or unsafe HTML style embedding; the app has no runtime user-CSS processing and ships a separate CSS file. These conditions limit the observed static artifact exposure but do not erase developer/CI risks.

Required security correction should be a separate reviewed change: select compatible Vite/plugin versions beyond all reported affected ranges, refresh affected transitives, and default development/preview startup to loopback. Vite 7.3.2 alone is insufficient because this audit includes later advisories through 7.3.6. Re-run all checks and produce new hashes after any dependency correction. The release authority can separately evaluate a strictly static-dist release risk acceptance; this report does not accept that risk on its behalf.

## Reproducible findings, owners and release next steps

| ID | Severity / status | Reproduction and observation | Suggested owner / next step |
| --- | --- | --- | --- |
| CX-01 | P2 provenance; FAIL | Compare G2_INTEGRATION_MANIFEST.json entry .gitignore with checkout: file missing; expected SHA 6c12cbe2357b4b2397df3e8e170aeebe414079a3538a322613ebb05b449c0086 | A/Release: reconcile authoritative package manifest versus repository export; do not silently create a replacement and call it original |
| CX-02 | High dependency risk; FAIL | npm audit --json exits 1; default dev script/config binds 0.0.0.0 with affected Vite 7.3.1; other build-tool findings also apply to malicious input conditions | Release Engineering/A: separate toolchain/lockfile correction or explicit scoped risk decision before clean-security sign-off |
| CX-03 | P3 decorative contrast; automated FAIL/manual review | At 1440×900, run axe on Discover with a saved Bridge entry: two aria-hidden ordinal spans have contrast 3.02:1 | A/E: confirm decorative exception or darken text in separate revision; raw FAIL retained |
| CX-04 | P3 semantics observation | axe incomplete aria-prohibited-attr points to generic div aria-label on branding/current aid | A/D: semantic cleanup; visible text exists, no observed workflow blocker |
| CX-05 | P3 console polish | GET /favicon.ico returns 404; first browser page logs one failed-resource error | A: add intended favicon in a separate task if desired |
| CX-06 | Acceptance gap; BLOCKED | Native zoom extension service worker did not start; CDP retry rejected unpacked extension loading by administrator | E: execute actual browser-menu/Ctrl++ 200% zoom in a permitted browser and inspect detail/plan/reflow; do not change managed browser policy |

To move from HOLD: reconcile CX-01, resolve or explicitly classify/accept CX-02 for the chosen distribution model, complete native zoom, and have E adjudicate remaining accessibility observations against its acceptance criteria. No functional domain/persistence rule correction is proposed. Screen-reader certification remains UNRUN and must not be inferred from keyboard/live-region DOM checks.

## Bundle map and reproduction

- `CODEX_QA_REPORT.md`: this disposition.
- `COMMANDS_AND_ENVIRONMENT.md`: exact commands, cwd, tool versions, exit codes and harness-error diagnoses.
- `ACCESSIBILITY_OBSERVATIONS.md`, `SECURITY_CLASSIFICATION.md`: detailed review.
- `logs/`: complete repository/browser test logs, structured results, console events, axe output and exit-code files.
- `screenshots/`: 56 actual captures.
- `audits/`: full audit JSON/stderr, dependency tree and advisory evidence.
- `dist/`, inventory, hashes, module list and artifact scan: exact compiled files tested.
- `source-before.json`, `source-after.json`, manifest verification: preservation/provenance evidence.
- `harness/`: isolated QA scripts and dependency metadata; no node_modules or browser profiles.

Each evidence file has a checksum in EVIDENCE_SHA256SUMS.txt. The ZIP's SHA-256 is supplied alongside it. The source checkout remains untouched; retained local helper files live outside it. Publication, external ingress and organiser submission were not performed.
