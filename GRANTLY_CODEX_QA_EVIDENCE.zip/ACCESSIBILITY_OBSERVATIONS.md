# Accessibility observations

Tested Chromium 156 with Playwright 1.57.0 and axe-core 4.14.0 against the production artifact. Automated rules were WCAG 2 A/AA and WCAG 2.1 AA tags. This is a bounded accessibility review, not WCAG certification or screen-reader acceptance.

## Executed checks

- PASS: Tab first reaches “Skip to main content”; Enter moves focus to the main element.
- PASS: keyboard Enter selects a scholarship. Detail heading receives focus; mobile Back restores the originating result button. Detail opened from My plan returns focus to its View current terms button on desktop and mobile.
- PASS: native keyboard End/Enter changes Fieldwork aid from Campus Tuition Waiver to Founders Tuition Award. Focus stays on the aid select. The polite, atomic status region contains: “Study context updated. Fieldwork Materials Grant: listed academic criteria met; application permitted; holding prohibited.” See logs/live-region.txt and keyboard-sequence.json.
- PASS: labelled native select controls, mobile Edit expansion, readable saved plan, review acknowledgement and reset controls were exercised. Application/holding labels and reasons distinguish the outcomes without depending only on colour.
- PASS: document width did not exceed viewport width for the checked desktop, 390px, 360px and 720px reflow views. Screenshots show wrapped content; the long submitted-progress option is visually truncated in the native select at 360px, while the following visible self-reported/no-submission explanation remains readable.

## Automated findings and manual classification

The primary runner deliberately fails when axe reports any violation. It completed **20 PASS, 1 FAIL**, exit 1. The FAIL is the desktop detail contrast rule, with two nodes: the decorative “01” and “02” ordinal spans next to “Can I apply?” and “Can I hold both awards?”. Measured contrast is 3.02:1 (#6d9680 on #f3f5f1), versus 4.5:1 for small text. The same information is conveyed by fully visible question text; the ordinal spans are aria-hidden and decorative. Manual classification: P3 visual improvement / decorative-text contrast exception candidate; not evidence of unreadable application or holding results. Preserve the automated FAIL for E's review; it has not been suppressed. A may darken the ordinal colour in a separate coding change if desired.

All checked plan views and the 390px, 360px and 720px detail views had zero axe violations. Raw JSON includes passes, incomplete checks, tool version and node selectors.

Incomplete aria-prohibited-attr checks identify aria-label on generic divs: .g-brand and .gd-context. These generic labels are not reliably exposed as accessible names. Visible GRANTLY branding and the current aid text are present as ordinary text. Suggested owner A for .g-brand, D for .gd-context; P3 semantics cleanup, remove redundant generic labels or use an appropriate semantic container in a separate task. No claim that this is an accessible “home” link: the brand is not a link.

Incomplete contrast checks involve decorative aria-hidden symbols (minus, tick and downward arrow). Adjacent visible labels communicate Edit/Done, listed criteria and required documents. These are retained as manual review observations, not counted as automated passes on contrast.

## 200% zoom and assistive technology limits

PASS: the **reflow-equivalent viewport** at 720×450 CSS pixels (half a 1440×900 viewport) supports detail, saving, plan and automated layout checks. Files named zoom200-* are this reflow simulation, not native browser zoom.

BLOCKED: an actual native 200% browser-zoom attempt was made with a QA-only extension using chrome.tabs.setZoom. Chromium did not load its service worker; a second diagnostic attempt through CDP Extensions.loadUnpacked returned “Loading of unpacked extensions is disabled by the administrator.” No policy was changed or bypassed. Logs/native-zoom-initial.log and native-zoom-run.log preserve the failure. This leaves native zoom acceptance incomplete; retest in a browser permitting normal Ctrl++ or browser-menu zoom and verify the zoom indicator is 200%.

UNRUN: NVDA, JAWS, VoiceOver, Orca or any other screen reader; speech output; Windows browser/OS-specific accessibility; Firefox/WebKit; actual mobile devices and touch gestures. DOM live-region text and keyboard focus are observed, not proof that assistive technology announced it correctly.

Release consequence: these observations support the tested keyboard flows. Full accessibility acceptance remains incomplete pending E's decorative-contrast adjudication and native zoom validation; no screen-reader PASS is issued.
