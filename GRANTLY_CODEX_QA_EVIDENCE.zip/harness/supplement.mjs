import {chromium} from '/opt/codex/cua_node/lib/node_modules/playwright/index.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
const out='/workspace/grantly-qa/evidence';const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const results=[];
for(const width of [1440,390,360]){
 const c=await b.newContext({viewport:{width,height:900}});const p=await c.newPage();const errors=[];const responses=[];
 p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.status()>=400)responses.push({url:r.url(),status:r.status()})});
 try{
 await p.goto('http://127.0.0.1:4173');if(width<900)await p.getByRole('button',{name:/^Edit/}).click();
 await p.locator('#g-profile-year').selectOption('1');await p.locator('#g-profile-aid').selectOption('CW');
 await p.locator('#g-opportunity-row-M').focus();await p.keyboard.press('Enter');await p.waitForTimeout(250);
 await p.getByRole('button',{name:'Save as an alternative',exact:true}).click();await p.getByRole('button',{name:'My plan 1',exact:true}).click();assert.equal(await p.locator('#gd-intent-M').inputValue(),'alternative');
 await p.getByRole('button',{name:'Discover',exact:true}).click();await p.locator('#g-opportunity-row-F').click();await p.waitForTimeout(250);await p.getByRole('button',{name:'Save to pursue',exact:true}).click();
 await p.getByRole('button',{name:'My plan 2',exact:true}).click();assert.equal(await p.locator('#gd-intent-F').inputValue(),'pursue');
 await p.locator('#gd-progress-F').selectOption('preparing');await p.reload();await p.getByRole('button',{name:'My plan 2',exact:true}).click();assert.equal(await p.locator('#gd-progress-F').inputValue(),'preparing');
 if(!await p.locator('#g-profile-year').isVisible())await p.getByRole('button',{name:/^Edit/}).click();
 await p.locator('#g-profile-aid').selectOption('FT');assert.equal(await p.locator('.gd-review').count(),2);
 await p.locator('article[aria-labelledby="gd-title-F"]').getByRole('button',{name:'Acknowledge review',exact:true}).click();assert.equal(await p.locator('.gd-review').count(),1);
 assert.equal(await p.locator('#gd-intent-F').inputValue(),'pursue');assert.equal(await p.locator('#gd-progress-F').inputValue(),'preparing');
 await p.screenshot({path:`${out}/screenshots/${width}-multiple-saved-review.png`,fullPage:true});
 await p.getByRole('button',{name:'View current terms',exact:true}).nth(1).click();await p.waitForTimeout(200);assert.equal(await p.evaluate(()=>document.activeElement.id),'g-detail-heading');
 await p.getByRole('button',{name:/Back to previous/}).click();await p.waitForTimeout(200);assert.equal(await p.evaluate(()=>document.activeElement.id),'g-plan-open-F');
 await p.getByRole('button',{name:'Remove Fieldwork Materials Grant from your plan',exact:true}).click();assert.equal(await p.locator('#gd-intent-F').count(),0);
 assert.deepEqual(errors,[]);results.push({width,status:'PASS',checks:['keyboard Enter selects Meridian','Meridian alternative','Fieldwork pursue','multiple-entry refresh','two independent review flags','targeted acknowledgement retains intention/progress','Back from plan restores focus','remove opportunity'],responses,errors});
 }catch(e){results.push({width,status:'FAIL',error:e.stack,responses,errors});}
 await c.close();
}
const c=await b.newContext();const response=await c.request.get('http://127.0.0.1:4173/favicon.ico');results.push({check:'favicon',httpStatus:response.status(),note:'Direct request identifies initial console 404'});await c.close();
fs.writeFileSync(`${out}/logs/supplement-results.json`,JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));await b.close();process.exitCode=results.some(x=>x.status==='FAIL')?1:0;
