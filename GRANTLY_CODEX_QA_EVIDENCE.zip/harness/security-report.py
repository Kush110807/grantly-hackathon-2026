import json,pathlib
o=pathlib.Path('/workspace/grantly-qa/evidence');r=pathlib.Path('/workspace/grantly-hackathon-2026/GRANTLY_GITHUB_SOURCE_ONLY')
a=json.loads((o/'audits/npm-audit.json').read_text());lock=json.loads((r/'package-lock.json').read_text())
conditions={
'GHSA-4w7w-66w2-5vf9':'Network-reachable Vite development server and predictable sensitive .map files; optimized-dependency map traversal. Not a static-dist endpoint.',
'GHSA-v2wj-q39q-566r':'Network-reachable development server; denied sensitive file exists within an allowed directory; query variants bypass fs.deny.',
'GHSA-p9ff-h696-f583':'Network-reachable development server with WebSocket enabled; attacker can connect without an Origin and invoke fetchModule. Arbitrary host file disclosure.',
'GHSA-v6wh-96g9-6wx3':'Windows with NTLM enabled, running launch-editor middleware, attacker website/request and known endpoint; UNC path can disclose NTLMv2 hash. Linux QA does not test Windows exploitability.',
'GHSA-698v-4r3x-3vcv':'Windows editor shell invocation with crafted filename plus malicious environment expansion or NTFS stream; percent escaping is incomplete. Later existence-check advisory weakens file-placement prerequisite.',
'GHSA-r825-w8mm-5pxw':'Attacker-controlled + or - filesystem entry and susceptible editor; Vite-specific scenario requires WSL. Editor interprets filename as CLI commands/flags.',
'GHSA-587h-7wmj-h5pm':'Windows launch-editor path ending in backslash parent/line suffix bypasses existence check; combined with percent expansion issue can cause command injection.',
'GHSA-9jrq-w75r-8gcw':'Custom/middleware Vite app forwards unchanged request URL into transformIndexHtml, contains inline module, and exposes sensitive state/actions. Standard SPA internal call does not meet this condition; no custom middleware found here.',
'GHSA-rq7h-c2jc-7f22':'Non-Windows network-exposed dev server; imported root-relative path also names a readable host absolute path, not denied by fs.deny. No matching project import observed.',
'GHSA-fx2h-pf6j-xcff':'Windows Vite development serving and alternate Windows path spellings bypass deny rules. Not Linux/static artifact.',
'GHSA-qx2v-qp2m-jg93':'Attacker CSS is stringified and embedded unsafely in an HTML style element. GRANTLY ships trusted CSS as a separate linked .css asset; no user CSS pipeline found.',
'GHSA-6g55-p6wh-862q':'Attacker controls CSS sourceMappingURL passed to PostCSS with previous-map loading; readable host paths and error/map output can expose files. Build-time input trust matters.',
'GHSA-fxqj-rqcc-2cmp':'PostCSS incomplete source-map fix; attacker CSS sourceMappingURL, especially with from unset, reads arbitrary .map files. Trusted source build observed; no runtime CSS processing.',
'GHSA-r28c-9q8g-f849':'PostCSS auto-loads previous .map from attacker-controlled CSS with traversal unless map loading disabled; generated maps can disclose sourcesContent. Trusted project CSS only observed.',
'GHSA-4x5r-pxfx-6jf8':'Attacker controls code compiled by Babel, knows source-map path and can read resulting output. Trusted-only compilation is not impacted according to advisory.',
'GHSA-w5vr-8v7q-w6rv':'Untrusted invalid/conflicting baseline-browser-mapping parameters can terminate calling process; build-tool input validation/availability risk.',
'GHSA-c83g-rgw3-j3cx':'Long-lived Browserslist caller accepts many distinct untrusted queries/context values; unbounded caches exhaust memory. Fixed trusted build queries here.',
'GHSA-73wf-gq98-2v4g':'Untrusted browserslist-stats.json or programmatic stats can crash/prototype-write during normalization; prevent attacker-controlled build metadata.',
'GHSA-g7r4-m6w7-qqqr':'esbuild standalone serve on Windows with crafted backslash path traversals; no esbuild serve process used in this Linux static-preview QA.',
'GHSA-28wg-ghj8-5hjv':'Attacker-controlled negative size passed to nanoid/non-secure generation can loop forever. No nanoid browser module bundled.',
'GHSA-2v37-7h3g-55p8':'Attacker-controlled zero size in customAlphabet/customRandom can loop forever. No nanoid browser module bundled.',
'GHSA-xwg4-73v4-xw9w':'Attacker-influenced huge nanoid size overflows signed integer, corrupting random pool and producing deterministic IDs. No nanoid browser module bundled.',
'GHSA-3v7f-55p6-f55p':'Untrusted POSIX bracket glob patterns can reference inherited object methods and alter matching; not remote code execution per advisory.',
'GHSA-c2c7-rcm5-vvqj':'Untrusted crafted extglob patterns plus nonmatching input cause catastrophic regex backtracking; developer-controlled glob patterns here.',
'GHSA-mw96-cpmx-2vgc':'Attacker controls Rollup named inputs, output aliases or plugin-generated filenames with traversal; build host arbitrary file write. Current trusted index.html input only.',
'GHSA-68fv-2mgg-jv7q':'Attacker supplies indexed source map with huge section offsets, blocking source-map-js event loop; build-tool availability risk, not bundled browser code.'
}
lines=['# Dependency security classification','', 'Audit fetched 7 November 2026. Full unmodified JSON and stderr are in audits/. No audit fix or dependency change was performed.', '',
'`npm audit --json`: exit **1**, 18 affected package records: 10 high, 4 moderate, 4 low, 0 critical. These are package records including propagated findings, not 18 independent exploits.', '',
'`npm audit --omit=dev --json`: exit **0**, no reported production vulnerabilities. Browser runtime is React 19.2.4, react-dom 19.2.4 and transitive scheduler 0.27.0. The production module inventory confirms production React/scheduler plus application modules; Vite/PostCSS/Rollup/Babel are not browser runtime modules.', '',
'All affected package records below belong to development/build dependencies. A dev-only label does not protect a developer or CI host processing malicious input. No advisory exploit PoCs were run; classification uses dependency tree, configuration, compiled-module inventory and fetched GitHub advisory text.', '',
'## Affected packages','', '| Package | Installed version | Relationship | npm severity | Finding propagation |','| --- | --- | --- | --- | --- |']
for n,v in a['vulnerabilities'].items():
 version=lock['packages'].get('node_modules/'+n,{}).get('version','unknown')
 via=', '.join(x if isinstance(x,str) else x['url'].rsplit('/',1)[-1] for x in v['via'])
 lines.append(f"| {n} | {version} | {'Direct devDependency' if v['isDirect'] else 'Transitive dev/build'} | {v['severity']} | {via} |")
lines+=['','## Advisory conditions and observed scope','', 'The severity below is each underlying advisory severity; parent package aggregate severity can differ. Complete fetched descriptions and reference links are preserved in audits/advisories/.', '']
for n,v in a['vulnerabilities'].items():
 for item in v['via']:
  if isinstance(item,dict):
   key=item['url'].rsplit('/',1)[-1]
   lines += [f"### {n}: {key} ({item['severity']})",'',item['title']+'.', '',f"Affected range reported by audit: `{item['range']}`. {conditions.get(key,'See fetched advisory for conditions.')}",'',f"Source: {item['url']}",'']
lines += ['## Vite and PostCSS release implications','',
'Vite 7.3.1 is a direct devDependency. package.json dev and preview scripts explicitly bind 0.0.0.0; vite.config.ts also sets server.host to 0.0.0.0. The development server therefore meets the network-binding prerequisite of the three original Vite file-read advisories if reachable by an attacker. Actual external ingress was not probed. This QA stopped the earlier onboarding servers and only ran the production preview with the final explicit --host 127.0.0.1 override; ss confirmed 127.0.0.1:4173 and no 5173 listener. Preview/static hosting does not execute Vite development HMR/fetchModule handlers. Do not deploy npm run dev or npm run preview as production hosting.', '',
'PostCSS 8.5.6 is transitively installed through Vite. The XSS advisory requires unsafe embedding of attacker CSS into a style element; this artifact instead links a generated CSS asset. File-read advisories concern the Node build process ingesting attacker sourceMappingURL comments; they are not a browser endpoint in dist. Trusted source inputs were built here, but untrusted CSS/dependency contributions still require an isolated build host and patched tooling.', '',
'Recommended separate correction owned by Release Engineering/A: update the pinned Vite/plugin toolchain to compatible releases outside ALL reported advisory ranges; refresh affected transitives (PostCSS, Rollup, Babel, Browserslist/baseline mapping, source-map-js, nanoid, picomatch and esbuild) in a separate reviewed lockfile change. Vite 7.3.2 only addresses the original three advisories; later reported ranges extend through 7.3.6, so upgrading merely to 7.3.2 is insufficient. Some aggregate audit records report fixAvailable=false; resolve compatible versions explicitly rather than assuming audit fix works. Keep development/preview loopback-only by default in that separate change, then rerun audits, tests and browser QA against the NEW bytes.', '',
'Static artifact disposition: no known production dependency findings were reported by this audit, and affected development/build packages are absent from its JavaScript module inventory. No evidence here establishes that every vulnerability is absent or that build infrastructure is hardened. An unqualified clean-security release claim is FAIL until tooling findings are corrected or explicitly accepted with documented scope by the release authority.'
]
(o/'SECURITY_CLASSIFICATION.md').write_text('\n'.join(lines)+'\n')
