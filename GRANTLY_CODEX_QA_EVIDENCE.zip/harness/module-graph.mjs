import {build} from '/workspace/grantly-hackathon-2026/GRANTLY_GITHUB_SOURCE_ONLY/node_modules/vite/dist/node/index.js';
import fs from 'node:fs';
// Run with the application directory as cwd: the repository pins input:'index.html'.
const root=process.cwd();
await build({configFile:root+'/vite.config.ts',plugins:[{name:'qa-module-evidence',generateBundle(_,bundle){
 const rows=Object.entries(bundle).map(([file,item])=>({file,type:item.type,modules:item.type==='chunk'?Object.keys(item.modules).map(x=>x.replace(root+'/','')):[]}));
 fs.writeFileSync('/workspace/grantly-qa/evidence/production-modules.json',JSON.stringify(rows,null,2));
}}]});
