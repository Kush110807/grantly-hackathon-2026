import hashlib,json,pathlib,re
r=pathlib.Path('/workspace/grantly-hackathon-2026/GRANTLY_GITHUB_SOURCE_ONLY')
out=pathlib.Path('/workspace/grantly-qa/evidence')
inventory=json.loads((out/'dist-inventory.json').read_text())
assert all(hashlib.sha256((r/'dist'/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in inventory)
patterns={
 'preview_or_development':r'preview-main|integration/fixtures|preview\.html|@vite/client|react-refresh|react(?:-dom)?[^\s]*\.development\.js',
 'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'github_token':r'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',
 'cloud_key':r'AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{35}',
 'service_token':r'sk-(?:proj-|live_|test_)?[A-Za-z0-9_-]{24,}|xox[baprs]-[A-Za-z0-9-]{20,}',
 'jwt':r'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}',
 'secret_assignment':r'''(?i)(?:api[_-]?key|secret|password|access[_-]?token)\s*[:=]\s*["'][^"']{8,}["']'''
}
result={k:[] for k in patterns}
for f in inventory:
 text=(r/'dist'/f['path']).read_text()
 for label,pat in patterns.items():
  for m in re.finditer(pat,text):result[label].append({'file':f['path'],'offset':m.start()})
modules=json.loads((out/'production-modules.json').read_text())
unexpected=[m for f in modules for m in f['modules'] if any(s in m for s in ['fixtures','preview-main','.development.js','@vite/client'])]
record={'status':'PASS' if not any(result.values()) and not unexpected else 'FAIL','scan_results':result,'unexpected_modules':unexpected,'method':'Every compiled file scanned; module graph recorded by a read-only generateBundle observer, followed by identical-byte check. Signature/assignment regexes are heuristic; absence is not a guarantee against all possible secrets.'}
(out/'artifact-scan.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
