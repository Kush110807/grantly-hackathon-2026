import json,pathlib,subprocess,concurrent.futures
from html.parser import HTMLParser
out=pathlib.Path('/workspace/grantly-qa/evidence/audits/advisories');out.mkdir(exist_ok=True)
class Extract(HTMLParser):
 def __init__(self):super().__init__();self.depth=0;self.parts=[]
 def handle_starttag(self,t,a):
  if self.depth:
   if t=='div':self.depth+=1
   if t in ['p','h2','h3','h4','li','br','pre']:self.parts.append('\n')
  elif t=='div' and 'markdown-body' in dict(a).get('class',''):self.depth=1
 def handle_endtag(self,t):
  if self.depth and t=='div':self.depth-=1
 def handle_data(self,d):
  if self.depth:self.parts.append(d)
a=json.load(open(out.parent/'npm-audit.json')); items={v['url']:v for n in a['vulnerabilities'].values() for v in n['via'] if isinstance(v,dict)}
def get(item):
 url,v=item; r=subprocess.run(['curl','-fsSL','--max-time','25',url],capture_output=True,text=True);p=Extract();p.feed(r.stdout)
 result={'url':url,'exit_code':r.returncode,'text':''.join(p.parts).strip(),'stderr':r.stderr};(out/(url.rsplit('/',1)[-1]+'.json')).write_text(json.dumps(result,indent=2));return (url,r.returncode,len(result['text']))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for r in ex.map(get,items.items()):print(*r)
