import {chromium} from '/opt/codex/cua_node/lib/node_modules/playwright/index.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const out='/workspace/grantly-qa/evidence';
const results=[],events=[];
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const base='http://127.0.0.1:4173';
async function test(name,fn){const start=new Date().toISOString();try{await fn();results.push({name,status:'PASS',start});console.log('PASS',name);}catch(e){results.push({name,status:'FAIL',start,error:e.stack});console.log('FAIL',name,e.message);}}
async function setup(viewport={width:1440,height:900},fault){
 const ctx=await browser.newContext({viewport});
 if(fault) await ctx.addInitScript(fault);
 const p=await ctx.newPage();p.setDefaultTimeout(7000);
 p.on('console',m=>events.push({type:'console',level:m.type(),text:m.text(),url:p.url()}));
 p.on('pageerror',e=>events.push({type:'pageerror',text:e.message,url:p.url()}));
 p.on('requestfailed',r=>events.push({type:'requestfailed',url:r.url(),failure:r.failure()}));
 await p.goto(base); await p.locator('#gc-search').waitFor();return {ctx,p};
}
async function profile(p,year='1',aid='CW',field='stem'){
 if(!await p.locator('#g-profile-year').isVisible())await p.getByRole('button',{name:/^Edit/}).click();
 await p.locator('#g-profile-year').selectOption(year);await p.locator('#g-profile-field').selectOption(field);await p.locator('#g-profile-aid').selectOption(aid);
}
const detail=p=>p.locator('.gc-detail');
async function choose(p,id){await p.locator('#g-opportunity-row-'+id).click();await detail(p).waitFor();await p.waitForTimeout(200);}
async function snap(p,name){await p.screenshot({path:`${out}/screenshots/${name}.png`,fullPage:true});}
async function text(p,pattern){assert.match(await p.innerText(),pattern);}
async function plan(p,n){await p.getByRole('button',{name:`My plan ${n}`,exact:true}).click();}
async function axe(p,name){await p.addScriptTag({path:'/workspace/grantly-qa/harness/node_modules/axe-core/axe.min.js'});const a=await p.evaluate(async()=>await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}}));fs.writeFileSync(`${out}/logs/axe-${name}.json`,JSON.stringify(a,null,2));return a;}

for(const [label,viewport] of [['desktop',{width:1440,height:900}],['mobile390',{width:390,height:844}],['mobile360',{width:360,height:844}]]){
 await test(`${label}: search/filter/selection/Back/focus`,async()=>{
  const {ctx,p}=await setup(viewport);
  try{
   assert.equal(await p.locator('.gc-result').count(),5);
   await p.locator('#gc-open-only').uncheck(); assert.equal(await p.locator('.gc-result').count(),6);
   await p.locator('#gc-search').fill('DEVICE');assert.equal(await p.locator('.gc-result').count(),1);await text(p.locator('.gc-result'),/Digital Access/);
   await p.locator('#gc-search').fill('no-such-scholarship');assert.equal(await p.locator('.gc-result').count(),0);
   await p.getByRole('button',{name:'Clear search and filters',exact:true}).first().click();
   await p.locator('#gc-search').fill('materials'); await choose(p,'F');await text(detail(p),/Fieldwork Materials Grant/);
   await p.waitForTimeout(150);assert.equal(await p.evaluate(()=>document.activeElement.id),'g-detail-heading');
   if(viewport.width<900){
    await detail(p).getByRole('button',{name:/Back to previous/}).click();await p.waitForTimeout(150);
    assert.equal(await p.evaluate(()=>document.activeElement.id),'g-opportunity-row-F');
   }else{
    // Desktop has an inline reading pane; its Back control is intentionally hidden.
    // Back from a plan-opened detail is exercised in the plan test at every width.
    assert.equal(await p.locator('#g-opportunity-row-F').getAttribute('aria-current'),'true');
    await p.getByRole('button',{name:'My plan 0',exact:true}).click();
    await p.getByRole('button',{name:'Discover',exact:true}).click();await p.waitForTimeout(150);
    assert.equal(await p.evaluate(()=>document.activeElement.id),'g-results-list');
   }
   assert.equal(await p.locator('#gc-search').inputValue(),'materials');
   await snap(p,`${label}-search-back`);
   assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth), 'horizontal overflow');
  }finally{await ctx.close();}
 });
 await test(`${label}: Meridian/Fieldwork/Bridge and both aid presets`,async()=>{
  const {ctx,p}=await setup(viewport);try{
   await profile(p);
   for(const [id,name] of [['M','Meridian'],['F','Fieldwork'],['B','Bridge']]){
    for(const aid of ['CW','FT']){
     if(!await p.locator('#g-opportunity-row-'+id).isVisible())await p.getByRole('button',{name:'Discover',exact:true}).click();
     await choose(p,id);await profile(p,'1',aid);
     const d=detail(p);const stages=d.locator('.gc-stage-row');
     await text(stages.nth(0),/Permitted by the listed terms/);
     await text(stages.nth(1),id==='B'&&aid==='CW'?/Unresolved/:id==='F'&&aid==='CW'?/Permitted by the listed terms/:/Prohibited/);
     if(!await d.locator('details').evaluate(e=>e.open))await d.locator('summary').click();await text(d.locator('.gc-terms-body'),new RegExp(aid==='CW'?'Campus Tuition Waiver':'Founders Tuition Award'));
     if(id==='B')await text(d.locator('.gc-terms-body'),/no holding term/);
     await snap(p,`${label}-${name}-${aid}`);
     if(viewport.width<900)await d.getByRole('button',{name:/Back to previous/}).click();
    }
   }
   await profile(p,'3','CW');await choose(p,'M');await text(detail(p),/Year 3 is not among/);
   await snap(p,`${label}-Meridian-ineligible`);
  }finally{await ctx.close();}
 });
 await test(`${label}: save/progress/refresh/review/acknowledge/original Bridge question`,async()=>{
  const {ctx,p}=await setup(viewport);try{
   await profile(p);await choose(p,'B');await detail(p).getByRole('button',{name:'Save clarification question',exact:true}).click();
   await plan(p,1);const q='May I keep my Campus Tuition Waiver if I accept the Bridge Travel Bursary?';
   await text(p.locator('.gd-question'),new RegExp(q.replace('?','\\?')));
   await p.locator('#gd-progress-B').selectOption('preparing');await p.reload();await plan(p,1);
   assert.equal(await p.locator('#gd-progress-B').inputValue(),'preparing');
   await profile(p,'1','FT');await p.locator('.gd-review').waitFor();await text(p.locator('.gd-review'),/Holding both awards · Prohibited/);
   await text(p.locator('.gd-question'),/Original aid context: Campus Tuition Waiver/);
   await p.getByRole('button',{name:'Acknowledge review',exact:true}).click();assert.equal(await p.locator('.gd-review').count(),0);
   assert.equal(await p.locator('#gd-progress-B').inputValue(),'preparing');assert.equal(await p.locator('#gd-intent-B').inputValue(),'clarify');
   await text(p.locator('.gd-question'),/Campus Tuition Waiver/);await p.reload();await plan(p,1);assert.equal(await p.locator('.gd-review').count(),0);
   await p.getByRole('button',{name:'View current terms',exact:true}).click();await p.waitForTimeout(100);assert.equal(await p.evaluate(()=>document.activeElement.id),'g-detail-heading');
   await detail(p).getByRole('button',{name:/Back to previous/}).click();await p.waitForTimeout(100);assert.equal(await p.evaluate(()=>document.activeElement.id),'g-plan-open-B');
   await p.locator('#gd-progress-B').selectOption('submittedExternally');await text(p.locator('.gd-submission-note'),/No submission was sent/);
   await snap(p,`${label}-plan-preserved-question`);
   await p.evaluate(()=>localStorage.setItem('qa-unrelated','keep'));
   p.once('dialog',d=>d.dismiss());await p.getByRole('button',{name:'Reset demo',exact:true}).click();assert.equal(await p.locator('#gd-progress-B').inputValue(),'submittedExternally');
   p.once('dialog',d=>d.accept());await p.getByRole('button',{name:'Reset demo',exact:true}).click();
   assert.equal(await p.evaluate(()=>localStorage.getItem('grantly.v1')),null);assert.equal(await p.evaluate(()=>localStorage.getItem('qa-unrelated')),'keep');
   await plan(p,0);await text(p.locator('.gd-empty'),/Your plan is empty/);await snap(p,`${label}-reset`);
  }finally{await ctx.close();}
 });
}

await test('keyboard: skip link, native aid change, stable focus, specific polite live region',async()=>{
 const {ctx,p}=await setup();try{
  await p.keyboard.press('Tab');assert.equal(await p.locator(':focus').innerText(),'Skip to main content');await p.keyboard.press('Enter');assert.equal(await p.evaluate(()=>document.activeElement.id),'g-main');
  await profile(p);await choose(p,'F');await p.locator('#g-profile-aid').focus();await p.keyboard.press('End');await p.keyboard.press('Enter');
  assert.equal(await p.locator('#g-profile-aid').inputValue(),'FT');assert.equal(await p.evaluate(()=>document.activeElement.id),'g-profile-aid');
  await text(p.locator('#g-live-assessment'),/Fieldwork Materials Grant:.*application permitted; holding prohibited/);
  assert.equal(await p.locator('#g-live-assessment').getAttribute('aria-live'),'polite');
  fs.writeFileSync(`${out}/logs/live-region.txt`,await p.locator('#g-live-assessment').innerText());
  await snap(p,'keyboard-live-region');
  // Traverse all focusable controls using Tab; preserve actual focus sequence.
  const seq=[];for(let i=0;i<35;i++){await p.keyboard.press('Tab');seq.push(await p.evaluate(()=>({tag:document.activeElement.tagName,id:document.activeElement.id,text:document.activeElement.textContent?.slice(0,100)})));}
  fs.writeFileSync(`${out}/logs/keyboard-sequence.json`,JSON.stringify(seq,null,2));
 }finally{await ctx.close();}
});

for(const fault of ['write-throw','write-noop','get-throw','getter-throw','invalid','remove-throw','remove-noop']){
 await test(`storage: ${fault} warnings and reset`,async()=>{
  const {ctx,p}=await setup(); // fault injection is installed below on fresh navigation
  try{
   await p.addInitScript(({fault})=>{
    if(fault==='invalid')localStorage.setItem('grantly.v1','{bad-json');
    if(fault==='remove-throw'||fault==='remove-noop')localStorage.setItem('grantly.v1','{bad-json');
    if(fault==='write-throw')Storage.prototype.setItem=function(){throw new DOMException('QA quota','QuotaExceededError')};
    if(fault==='write-noop')Storage.prototype.setItem=function(){};
    if(fault==='get-throw')Storage.prototype.getItem=function(){throw new DOMException('QA denied','SecurityError')};
    if(fault==='getter-throw')Object.defineProperty(window,'localStorage',{get(){throw new DOMException('QA denied','SecurityError')}});
    if(fault==='remove-throw')Storage.prototype.removeItem=function(){throw new DOMException('QA denied','SecurityError')};
    if(fault==='remove-noop')Storage.prototype.removeItem=function(){};
   },{fault});
   await p.reload();await p.locator('#gc-search').waitFor();await profile(p);await choose(p,'B');await detail(p).getByRole('button',{name:'Save clarification question',exact:true}).click();await plan(p,1);
   await text(p.locator('.g-notice'),/couldn’t save|not overwritten/);await text(p.locator('.gd-heading'),/YOUR DECISIONS \/ YOUR PLAN/);
   assert.doesNotMatch(await p.locator('.gd-heading').innerText(),/SAVED ON THIS DEVICE/);
   await snap(p,`storage-${fault}-warning`);
   p.once('dialog',d=>d.accept());await p.getByRole('button',{name:'Reset demo',exact:true}).click();
   if(['get-throw','getter-throw','remove-throw','remove-noop'].includes(fault)){
    await text(p.locator('.g-notice'),/Couldn’t clear/);await text(p.locator('.gd-heading'),/1 opportunity/);
   }else{await text(p.locator('.g-notice'),/demo reset/);await plan(p,0);}
   if(['invalid','remove-throw','remove-noop'].includes(fault))assert.equal(await p.evaluate(()=>localStorage.getItem('grantly.v1')),fault==='invalid'?null:'{bad-json');
   await snap(p,`storage-${fault}-reset`);
  }finally{await ctx.close();}
 });
}

for(const [name,viewport] of [['desktop',{width:1440,height:900}],['mobile390',{width:390,height:844}],['mobile360',{width:360,height:844}],['zoom200',{width:720,height:450}]]){
 await test(`accessibility/layout: ${name}`,async()=>{
  const {ctx,p}=await setup(viewport);try{
   // 720x450 CSS viewport is the reflow equivalent of a 1440x900 browser at 200% zoom.
   await profile(p);await choose(p,'B');await detail(p).getByRole('button',{name:'Save clarification question',exact:true}).click();
   const a=await axe(p,name+'-detail');await snap(p,`${name}-accessibility-detail`);
   await plan(p,1);await profile(p,'1','FT');const b=await axe(p,name+'-plan');await snap(p,`${name}-accessibility-plan`);
   const metrics=await p.evaluate(()=>({innerWidth,scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth}));
   fs.writeFileSync(`${out}/logs/layout-${name}.json`,JSON.stringify(metrics));
   assert.ok(metrics.scrollWidth<=metrics.innerWidth,'horizontal overflow');
   assert.equal(a.violations.length+b.violations.length,0,`axe violations detail=${a.violations.map(v=>v.id)} plan=${b.violations.map(v=>v.id)}`);
  }finally{await ctx.close();}
 });
}
fs.writeFileSync(`${out}/logs/browser-events.json`,JSON.stringify(events,null,2));
fs.writeFileSync(`${out}/logs/browser-results.json`,JSON.stringify(results,null,2));
fs.writeFileSync(`${out}/logs/browser-environment.json`,JSON.stringify({browser:browser.version(),playwright:JSON.parse(fs.readFileSync('/opt/codex/cua_node/lib/node_modules/playwright/package.json')).version,base,started:new Date().toISOString()},null,2));
await browser.close();
process.exitCode=results.some(r=>r.status==='FAIL')?1:0;
