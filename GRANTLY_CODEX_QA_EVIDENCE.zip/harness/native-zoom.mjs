import {chromium} from '/opt/codex/cua_node/lib/node_modules/playwright/index.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
const out='/workspace/grantly-qa/evidence';const ext='/workspace/grantly-qa/zoom-extension';
const c=await chromium.launchPersistentContext('/workspace/grantly-qa/zoom-browser',{executablePath:'/usr/bin/chromium',headless:true,viewport:null,ignoreDefaultArgs:['--disable-extensions'],args:['--enable-unsafe-extension-debugging','--no-sandbox','--window-size=1440,987',`--disable-extensions-except=${ext}`,`--load-extension=${ext}`]});
try{
const p=await c.newPage();await p.goto('http://127.0.0.1:4173');
const session=await c.browser().newBrowserCDPSession();await session.send('Extensions.loadUnpacked',{path:ext});
const sw=c.serviceWorkers()[0]??await c.waitForEvent('serviceworker',{timeout:10000});
const before=await p.evaluate(()=>({innerWidth,innerHeight,outerWidth,outerHeight,devicePixelRatio}));
const zoom=await sw.evaluate(async()=>{const tabs=await chrome.tabs.query({url:'http://127.0.0.1:4173/*'});await chrome.tabs.setZoom(tabs[0].id,2);return await chrome.tabs.getZoom(tabs[0].id)});
await p.waitForTimeout(300);const after=await p.evaluate(()=>({innerWidth,innerHeight,outerWidth,outerHeight,devicePixelRatio,scrollWidth:document.documentElement.scrollWidth}));assert.equal(zoom,2);assert.equal(after.devicePixelRatio,2);assert.ok(after.innerWidth<=before.innerWidth/2+1);
if(!await p.locator('#g-profile-year').isVisible())await p.getByRole('button',{name:/^Edit/}).click();await p.locator('#g-profile-year').selectOption('1');await p.locator('#g-profile-aid').selectOption('CW');
await p.locator('#g-opportunity-row-B').click();await p.getByRole('button',{name:'Save clarification question',exact:true}).click();
await p.addScriptTag({path:'/workspace/grantly-qa/harness/node_modules/axe-core/axe.min.js'});const detailAxe=await p.evaluate(async()=>await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}}));fs.writeFileSync(`${out}/logs/axe-native-zoom-detail.json`,JSON.stringify(detailAxe,null,2));await p.screenshot({path:`${out}/screenshots/native-200-percent-detail.png`,fullPage:true});
await p.getByRole('button',{name:'My plan 1',exact:true}).click();await p.locator('#gd-progress-B').selectOption('preparing');await p.reload();await p.getByRole('button',{name:'My plan 1',exact:true}).click();assert.equal(await p.locator('#gd-progress-B').inputValue(),'preparing');
await p.addScriptTag({path:'/workspace/grantly-qa/harness/node_modules/axe-core/axe.min.js'});const a=await p.evaluate(async()=>await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}}));fs.writeFileSync(`${out}/logs/axe-native-zoom-plan.json`,JSON.stringify(a,null,2));await p.screenshot({path:`${out}/screenshots/native-200-percent-plan.png`,fullPage:true});assert.equal(detailAxe.violations.length+a.violations.length,0);assert.ok(after.scrollWidth<=after.innerWidth);
fs.writeFileSync(`${out}/logs/native-zoom.json`,JSON.stringify({status:'PASS',method:'Chromium extension chrome.tabs.setZoom(tabId,2); verified chrome.tabs.getZoom()=2, devicePixelRatio=2 and halved CSS viewport. This is native page zoom, not CSS zoom or device scale emulation.',before,after,zoom,checks:['search/list and profile controls usable','Bridge detail and save','plan progress persists on refresh','no horizontal overflow','axe detail/plan no violations']},null,2));console.log('PASS native browser zoom 200%',before,after);
}finally{await c.close();}
